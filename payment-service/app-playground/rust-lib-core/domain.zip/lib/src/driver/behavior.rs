
use teaql_runtime::EntityDataServiceBehavior;

#[derive(Clone, Debug, Default)]
pub struct DriverBehavior;

impl EntityDataServiceBehavior for DriverBehavior {}