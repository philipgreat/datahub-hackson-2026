
// ⛔ AI agents: DO NOT read this file for API discovery. Instead run: cargo teaql --input modeling/MODEL.xml rust-assist-query/payment_method
use std::collections::BTreeMap;

use teaql_core::SmartList;
use teaql_macros::TeaqlEntity;

/// [TEAQL AI WARNING]
/// TeaQL was explicitly designed to PREVENT AI hallucinations and random guessing.
/// DO NOT GUESS METHOD NAMES!
/// The methods listed below are the ONLY valid ways to interact with this entity.
/// If you encounter compilation errors (e.g., method not found), DO NOT guess another method name.
/// Read the method signatures in this file before proceeding.
#[derive(Clone, Debug, PartialEq, TeaqlEntity)]
#[teaql(entity = "PaymentMethod", table = "payment_method_data", data_service = "sqlite", audit_mask_fields = "payment_account,last_four_digits")]
pub struct PaymentMethod {
#[teaql(id)]
    id: u64,

// @source payment.xml:26
    method_type: String,

// @source payment.xml:26
    last_four_digits: i64,

// @source payment.xml:26
    create_time: teaql_core::time::Timestamp,

// @source payment.xml:26
    update_time: teaql_core::time::Timestamp,
#[teaql(version)]
    version: i64,
// @source payment.xml:26
#[teaql(column = "payment_account")]
    payment_account_id: u64,
// @source payment.xml:26
#[teaql(relation(target = "PaymentAccount", local_key = "payment_account_id", foreign_key = "id"))]
    payment_account: Option<crate::PaymentAccount>,
#[teaql(relation(target = "PaymentTransaction", local_key = "id", foreign_key = "payment_method_id", many))]
    payment_transaction_list: SmartList<crate::PaymentTransaction>,
    #[teaql(dynamic)]
    dynamic: BTreeMap<String, teaql_core::Value>,
    #[teaql(skip)]
    root: teaql_runtime::EntityRoot,
    #[teaql(skip)]
    pub __load_state: teaql_core::eval::LoadState,
}

impl PaymentMethod {
    pub fn with_id(id: u64) -> teaql_core::Value {
        teaql_core::Value::U64(id)
    }

    pub(crate) fn runtime_new(root: teaql_runtime::EntityRoot) -> Self {
        Self {
            id: 0_u64,
            method_type: String::new(),
            last_four_digits: 0_i64,
            create_time: teaql_core::time::Timestamp::now(),
            update_time: teaql_core::time::Timestamp::now(),
            version: 0_i64,
            payment_account_id: 0_u64,
            payment_account: None,
            payment_transaction_list: Default::default(),
            dynamic: BTreeMap::new(),
            root,
            __load_state: teaql_core::eval::LoadState::FullyLoaded,
        }
    }

    pub fn entity_key(&self) -> teaql_runtime::EntityKey {
        teaql_runtime::EntityKey::new("PaymentMethod", self.id)
    }

    pub fn attach_root_recursive(&mut self, root: teaql_runtime::EntityRoot) {
        self.root = root.clone();
        if let Some(entity) = &mut self.payment_account {
            entity.attach_root_recursive(root.clone());
        }
        for entity in &mut self.payment_transaction_list {
            entity.attach_root_recursive(root.clone());
        }
    }

    pub fn is_loaded(&self, field_or_relation: &str) -> bool {
        self.__load_state.is_loaded(field_or_relation)
    }

    pub fn set_load_state(&mut self, state: teaql_core::eval::LoadState) {
        self.__load_state = state;
    }

    pub fn id(&self) -> u64 {
        self.changed_id().and_then(|value| value.try_u64()).unwrap_or(self.id)
    }

    pub fn update_id(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.id = value.try_u64().unwrap_or(self.id.clone());
        self.root.set(self.entity_key(), "id", value);
        self
    }

    pub fn changed_id(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "id")
    }

    pub fn eval_id(&self) -> teaql_core::eval::EvalResult<u64> {
        if !self.is_loaded("id") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "id".to_string(), attempted_path: "id".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.id())
                }}

    pub fn method_type(&self) -> String {
        self.changed_method_type().and_then(|value| value.try_text().map(|value| value.to_owned())).unwrap_or_else(|| self.method_type.clone())
    }

    pub fn update_method_type(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.method_type = value.try_text().map(|value| value.trim().to_owned()).unwrap_or_else(|| self.method_type.clone());
        self.root.set(self.entity_key(), "method_type", value);
        self
    }

    pub fn changed_method_type(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "method_type")
    }

    pub fn eval_method_type(&self) -> teaql_core::eval::EvalResult<String> {
        if !self.is_loaded("method_type") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "method_type".to_string(), attempted_path: "method_type".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.method_type())
                }}

    pub fn last_four_digits(&self) -> i64 {
        self.changed_last_four_digits().and_then(|value| value.try_i64()).map(|value| value as i64).unwrap_or(self.last_four_digits)
    }

    pub fn update_last_four_digits(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.last_four_digits = value.try_i64().map(|value| value as i64).unwrap_or(self.last_four_digits.clone());
        self.root.set(self.entity_key(), "last_four_digits", value);
        self
    }

    pub fn changed_last_four_digits(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "last_four_digits")
    }

    pub fn eval_last_four_digits(&self) -> teaql_core::eval::EvalResult<i64> {
        if !self.is_loaded("last_four_digits") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "last_four_digits".to_string(), attempted_path: "last_four_digits".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.last_four_digits())
                }}

    pub fn create_time(&self) -> teaql_core::time::Timestamp {
        self.changed_create_time().and_then(|value| value.try_timestamp()).unwrap_or(self.create_time)
    }

    pub fn update_create_time(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.create_time = value.try_timestamp().unwrap_or(self.create_time.clone());
        self.root.set(self.entity_key(), "create_time", value);
        self
    }

    pub fn changed_create_time(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "create_time")
    }

    pub fn eval_create_time(&self) -> teaql_core::eval::EvalResult<teaql_core::time::Timestamp> {
        if !self.is_loaded("create_time") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "create_time".to_string(), attempted_path: "create_time".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.create_time())
                }}

    pub fn update_time(&self) -> teaql_core::time::Timestamp {
        self.changed_update_time().and_then(|value| value.try_timestamp()).unwrap_or(self.update_time)
    }

    pub fn update_update_time(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.update_time = value.try_timestamp().unwrap_or(self.update_time.clone());
        self.root.set(self.entity_key(), "update_time", value);
        self
    }

    pub fn changed_update_time(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "update_time")
    }

    pub fn eval_update_time(&self) -> teaql_core::eval::EvalResult<teaql_core::time::Timestamp> {
        if !self.is_loaded("update_time") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "update_time".to_string(), attempted_path: "update_time".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.update_time())
                }}

    pub fn version(&self) -> i64 {
        self.changed_version().and_then(|value| value.try_i64()).unwrap_or(self.version)
    }

    pub fn update_version(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.version = value.try_i64().unwrap_or(self.version.clone());
        self.root.set(self.entity_key(), "version", value);
        self
    }

    pub fn changed_version(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "version")
    }

    pub fn eval_version(&self) -> teaql_core::eval::EvalResult<i64> {
        if !self.is_loaded("version") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "version".to_string(), attempted_path: "version".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.version())
                }}
    pub fn payment_account_id(&self) -> u64 {
        self.changed_payment_account_id().and_then(|value| value.try_u64()).unwrap_or(self.payment_account_id)
    }

    pub fn update_payment_account_id(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.payment_account_id = value.try_u64().unwrap_or(self.payment_account_id.clone());
        self.root.set(self.entity_key(), "payment_account_id", value);
        self
    }

    pub fn changed_payment_account_id(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "payment_account_id")
    }

    pub fn eval_payment_account_id(&self) -> teaql_core::eval::EvalResult<u64> {
        if !self.is_loaded("payment_account_id") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "payment_account_id".to_string(), attempted_path: "payment_account_id".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.payment_account_id())
                }}
    pub fn payment_account(&self) -> Option<&crate::PaymentAccount> {
        self.payment_account.as_ref()
    }

    pub fn eval_payment_account(&self) -> teaql_core::eval::EvalResult<&crate::PaymentAccount> {
        if !self.is_loaded("payment_account") {
            teaql_core::eval::EvalResult::NotLoaded { failed_node: "payment_account".to_string(), attempted_path: "payment_account".to_string() }
        } else {
            match &self.payment_account {
                Some(v) => teaql_core::eval::EvalResult::Value(v),
                None => teaql_core::eval::EvalResult::Null,
            }
        }
    }
    pub fn payment_transaction_list(&self) -> &SmartList<crate::PaymentTransaction> {
        &self.payment_transaction_list
    }

    pub fn payment_transaction_list_mut(&mut self) -> &mut SmartList<crate::PaymentTransaction> {
        &mut self.payment_transaction_list
    }

    pub fn eval_payment_transaction_list(&self) -> teaql_core::eval::EvalResult<&SmartList<crate::PaymentTransaction>> {
        if !self.is_loaded("payment_transaction_list") {
            teaql_core::eval::EvalResult::NotLoaded { failed_node: "payment_transaction_list".to_string(), attempted_path: "payment_transaction_list".to_string() }
        } else {
            teaql_core::eval::EvalResult::Value(&self.payment_transaction_list)
        }
    }

    pub fn mark_as_delete(&mut self) -> &mut Self {
        self.root.mark_as_delete(self.entity_key());
        self
    }

    pub fn set_comment(&mut self, comment: impl Into<String>) -> &mut Self {
        self.root.set_comment(comment);
        self
    }
}

