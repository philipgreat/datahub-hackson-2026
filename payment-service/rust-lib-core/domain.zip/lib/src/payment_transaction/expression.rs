#[derive(Clone)]
pub struct PaymentTransactionExpression<'a> {
    result: teaql_core::eval::EvalResult<&'a crate::PaymentTransaction>,
    root_desc: std::sync::Arc<String>,
}

impl<'a> PaymentTransactionExpression<'a> {
    pub fn new(result: teaql_core::eval::EvalResult<&'a crate::PaymentTransaction>, root_desc: std::sync::Arc<String>) -> Self {
        Self { result, root_desc }
    }

    fn resolve(&self) -> Option<&'a crate::PaymentTransaction> {
        match &self.result {
            teaql_core::eval::EvalResult::Value(v) => Some(*v),
            teaql_core::eval::EvalResult::Null => None,
            teaql_core::eval::EvalResult::NotLoaded { failed_node, attempted_path } => {
                crate::trigger_logic_bug_panic(&self.root_desc, &failed_node, &attempted_path)
            }
        }
    }

    pub fn eval(&self) -> Option<&'a crate::PaymentTransaction> {
        self.resolve()
    }

    pub fn unwrap(&self) -> &'a crate::PaymentTransaction {
        self.resolve().expect("Relation was legitimately null in database!")
    }

    pub fn get_id(self) -> crate::ValueExpression<'a, u64> {
        let next = self.result.and_then("id", |entity| entity.eval_id());
        crate::ValueExpression::new(next, self.root_desc.clone())
    }

    pub fn get_transaction_amount(self) -> crate::ValueExpression<'a, rust_decimal::Decimal> {
        let next = self.result.and_then("transaction_amount", |entity| entity.eval_transaction_amount());
        crate::ValueExpression::new(next, self.root_desc.clone())
    }

    pub fn get_currency_code(self) -> crate::ValueExpression<'a, String> {
        let next = self.result.and_then("currency_code", |entity| entity.eval_currency_code());
        crate::ValueExpression::new(next, self.root_desc.clone())
    }

    pub fn get_reference_number(self) -> crate::ValueExpression<'a, String> {
        let next = self.result.and_then("reference_number", |entity| entity.eval_reference_number());
        crate::ValueExpression::new(next, self.root_desc.clone())
    }

    pub fn get_create_time(self) -> crate::ValueExpression<'a, teaql_core::time::Timestamp> {
        let next = self.result.and_then("create_time", |entity| entity.eval_create_time());
        crate::ValueExpression::new(next, self.root_desc.clone())
    }

    pub fn get_update_time(self) -> crate::ValueExpression<'a, teaql_core::time::Timestamp> {
        let next = self.result.and_then("update_time", |entity| entity.eval_update_time());
        crate::ValueExpression::new(next, self.root_desc.clone())
    }

    pub fn get_version(self) -> crate::ValueExpression<'a, i64> {
        let next = self.result.and_then("version", |entity| entity.eval_version());
        crate::ValueExpression::new(next, self.root_desc.clone())
    }
    pub fn get_payment_account_id(self) -> crate::ValueExpression<'a, u64> {
        let next = self.result.and_then("payment_account_id", |entity| entity.eval_payment_account_id());
        crate::ValueExpression::new(next, self.root_desc.clone())
    }

    pub fn get_payment_method_id(self) -> crate::ValueExpression<'a, u64> {
        let next = self.result.and_then("payment_method_id", |entity| entity.eval_payment_method_id());
        crate::ValueExpression::new(next, self.root_desc.clone())
    }

    pub fn get_payment_status_id(self) -> crate::ValueExpression<'a, u64> {
        let next = self.result.and_then("payment_status_id", |entity| entity.eval_payment_status_id());
        crate::ValueExpression::new(next, self.root_desc.clone())
    }
    pub fn get_payment_account(self) -> crate::PaymentAccountExpression<'a> {
        let next = self.result.and_then("payment_account", |entity| entity.eval_payment_account());
        crate::PaymentAccountExpression::new(next, self.root_desc.clone())
    }

    pub fn get_payment_method(self) -> crate::PaymentMethodExpression<'a> {
        let next = self.result.and_then("payment_method", |entity| entity.eval_payment_method());
        crate::PaymentMethodExpression::new(next, self.root_desc.clone())
    }

    pub fn get_payment_status(self) -> crate::PaymentStatusExpression<'a> {
        let next = self.result.and_then("payment_status", |entity| entity.eval_payment_status());
        crate::PaymentStatusExpression::new(next, self.root_desc.clone())
    }
    pub fn payment_status_is_pending(self) -> crate::ValueExpression<'a, bool> {
        let next = self.result.and_then("payment_status_id", |entity| {
            if !entity.is_loaded("payment_status_id") {
                teaql_core::eval::EvalResult::NotLoaded { failed_node: "payment_status_id".to_string(), attempted_path: "payment_status_id".to_string() }
            } else {
                teaql_core::eval::EvalResult::Value(entity.payment_status_is_pending())
            }
        });
        crate::ValueExpression::new(next, self.root_desc.clone())
    }

    pub fn payment_status_is_success(self) -> crate::ValueExpression<'a, bool> {
        let next = self.result.and_then("payment_status_id", |entity| {
            if !entity.is_loaded("payment_status_id") {
                teaql_core::eval::EvalResult::NotLoaded { failed_node: "payment_status_id".to_string(), attempted_path: "payment_status_id".to_string() }
            } else {
                teaql_core::eval::EvalResult::Value(entity.payment_status_is_success())
            }
        });
        crate::ValueExpression::new(next, self.root_desc.clone())
    }

    pub fn payment_status_is_failed(self) -> crate::ValueExpression<'a, bool> {
        let next = self.result.and_then("payment_status_id", |entity| {
            if !entity.is_loaded("payment_status_id") {
                teaql_core::eval::EvalResult::NotLoaded { failed_node: "payment_status_id".to_string(), attempted_path: "payment_status_id".to_string() }
            } else {
                teaql_core::eval::EvalResult::Value(entity.payment_status_is_failed())
            }
        });
        crate::ValueExpression::new(next, self.root_desc.clone())
    }
}

#[derive(Clone)]
pub struct PaymentTransactionListExpression<'a> {
    result: teaql_core::eval::EvalResult<&'a teaql_core::SmartList<crate::PaymentTransaction>>,
    root_desc: std::sync::Arc<String>,
}

impl<'a> PaymentTransactionListExpression<'a> {
    pub fn new(result: teaql_core::eval::EvalResult<&'a teaql_core::SmartList<crate::PaymentTransaction>>, root_desc: std::sync::Arc<String>) -> Self {
        Self { result, root_desc }
    }

    fn resolve(&self) -> Option<&'a teaql_core::SmartList<crate::PaymentTransaction>> {
        match &self.result {
            teaql_core::eval::EvalResult::Value(v) => Some(*v),
            teaql_core::eval::EvalResult::Null => None,
            teaql_core::eval::EvalResult::NotLoaded { failed_node, attempted_path } => {
                crate::trigger_logic_bug_panic(&self.root_desc, &failed_node, &attempted_path)
            }
        }
    }

    pub fn eval(&self) -> Option<&'a teaql_core::SmartList<crate::PaymentTransaction>> {
        self.resolve()
    }

    pub fn unwrap(&self) -> &'a teaql_core::SmartList<crate::PaymentTransaction> {
        self.resolve().expect("List relation was legitimately null in database!")
    }

    pub fn size(&self) -> crate::ValueExpression<'a, usize> {
        let next = self.result.clone().and_then("size", |list| teaql_core::eval::EvalResult::Value(list.len()));
        crate::ValueExpression::new(next, self.root_desc.clone())
    }

    pub fn first(&self) -> crate::PaymentTransactionExpression<'a> {
        let next = self.result.clone().and_then("first", |list| {
            if let Some(item) = list.first() {
                teaql_core::eval::EvalResult::Value(item)
            } else {
                teaql_core::eval::EvalResult::Null
            }
        });
        crate::PaymentTransactionExpression::new(next, self.root_desc.clone())
    }

    pub fn get(&self, index: usize) -> crate::PaymentTransactionExpression<'a> {
        let next = self.result.clone().and_then("get", |list| {
            if let Some(item) = list.get(index) {
                teaql_core::eval::EvalResult::Value(item)
            } else {
                teaql_core::eval::EvalResult::Null
            }
        });
        crate::PaymentTransactionExpression::new(next, self.root_desc.clone())
    }
}