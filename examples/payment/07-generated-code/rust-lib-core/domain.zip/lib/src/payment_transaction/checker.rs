
use teaql_runtime::{CheckObjectStatus, CheckResults, ObjectLocation, TypedChecker, UserContext};

pub trait PaymentTransactionCheckerLogic: Send + Sync {
    fn check_and_fix_payment_transaction(
        &self,
        _ctx: &UserContext,
        _entity: &mut crate::PaymentTransaction,
        _status: CheckObjectStatus,
        _location: &ObjectLocation,
        _results: &mut CheckResults,
    ) {
    }

    fn required(
        &self,
        value: bool,
        field: &str,
        location: &ObjectLocation,
        results: &mut CheckResults,
    ) {
        if !value {
            results.push(teaql_runtime::CheckResult::required(location.clone().member(field)));
        }
    }

    fn required_option<V>(
        &self,
        value: Option<&V>,
        field: &str,
        location: &ObjectLocation,
        results: &mut CheckResults,
    ) {
        if value.is_none() {
            results.push(teaql_runtime::CheckResult::required(location.clone().member(field)));
        }
    }

    fn required_text(
        &self,
        value: &str,
        field: &str,
        location: &ObjectLocation,
        results: &mut CheckResults,
    ) {
        if value.trim().is_empty() {
            results.push(teaql_runtime::CheckResult::required(location.clone().member(field)));
        }
    }

    fn min_string_length(
        &self,
        value: &str,
        field: &str,
        min_len: usize,
        location: &ObjectLocation,
        results: &mut CheckResults,
    ) {
        if value.chars().count() < min_len {
            results.push(teaql_runtime::CheckResult::min_str(
                location.clone().member(field),
                min_len as u64,
                value.to_owned(),
            ));
        }
    }

    fn max_string_length(
        &self,
        value: &str,
        field: &str,
        max_len: usize,
        location: &ObjectLocation,
        results: &mut CheckResults,
    ) {
        if value.chars().count() > max_len {
            results.push(teaql_runtime::CheckResult::max_str(
                location.clone().member(field),
                max_len as u64,
                value.to_owned(),
            ));
        }
    }
}

#[derive(Clone, Debug, Default)]
pub struct NoopPaymentTransactionChecker;

impl PaymentTransactionCheckerLogic for NoopPaymentTransactionChecker {}

#[derive(Clone, Debug)]
pub struct PaymentTransactionChecker<L = NoopPaymentTransactionChecker> {
    logic: L,
}

impl Default for PaymentTransactionChecker<NoopPaymentTransactionChecker> {
    fn default() -> Self {
        Self {
            logic: NoopPaymentTransactionChecker,
        }
    }
}

impl<L> PaymentTransactionChecker<L>
where
    L: PaymentTransactionCheckerLogic,
{
    pub fn new(logic: L) -> Self {
        Self { logic }
    }
}

impl<L> TypedChecker<crate::PaymentTransaction> for PaymentTransactionChecker<L>
where
    L: PaymentTransactionCheckerLogic,
{
    fn check_and_fix_typed(
        &self,
        ctx: &UserContext,
        entity: &mut crate::PaymentTransaction,
        status: CheckObjectStatus,
        location: &ObjectLocation,
        results: &mut CheckResults,
    ) {
        if status == CheckObjectStatus::Create && entity.changed_create_time().is_none() {
            entity.update_create_time(teaql_core::time::Timestamp::now());
        }

        if status == CheckObjectStatus::Update && entity.changed_update_time().is_none() {
            entity.update_update_time(teaql_core::time::Timestamp::now());
        }


        self.logic
            .check_and_fix_payment_transaction(ctx, entity, status, location, results);
    }
}